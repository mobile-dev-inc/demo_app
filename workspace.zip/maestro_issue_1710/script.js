const myVar = 'foo';
console.log(myVar); // outputs 'foo'
console.log(`myVar is ${myVar}`) // outputs 'myVar is foo'
